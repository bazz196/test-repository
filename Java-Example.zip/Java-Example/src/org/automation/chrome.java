package org.automation;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class chrome {
	
private WebDriver driver;
//private WebDriverWait wait;



@Before	
public void start(){
	driver = new ChromeDriver();
	new WebDriverWait(driver, 10);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

@Test
public void myFirstTest() {

	driver.navigate().to("https://www.google.com/");
	driver.findElement(By.className("MiYK0e")).click();
	driver.findElement(By.id("K20")).click();
	driver.findElement(By.id("K71")).click();
	driver.findElement(By.id("K72")).click();
	driver.findElement(By.id("K66")).click();
	driver.findElement(By.id("K68")).click();
	driver.findElement(By.id("K84")).click();
	driver.findElement(By.id("K78")).click();
	driver.findElement(By.className("MiYK0e")).click();
	driver.findElement(By.name("btnK")).click();
	
}	
	
@After
public void stop(){
	//driver.quit();
	driver = null;
}



}
