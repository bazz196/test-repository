package org.automation;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.htmlunit.HtmlUnitDriver;


public class selenium {
//	WebDriver chromeDriver = new ChromeDriver();
//	WebDriver ieDriver = new InternetExplorerDriver();
//	WebDriver firefoxDriver = new FirefoxDriver();
	
//	public static void main(String[] args) {
//		WebDriver chromeDriver = new ChromeDriver();
//		chromeDriver.get("http://www.google.com");
//		
		

//		    public static void main(String[] args) {
	@Test	
	public void TestChrome() {
			
		        WebDriver driver = new ChromeDriver();
    	     //   driver.get("http://www.google.com");
		        driver.get("http://localhost/litecart/en/");
		        WebElement element = driver.findElement(By.name("query"));
		        element.sendKeys("Yellow Duck");
		        element.submit();
		        driver.quit();

		}
	@Test	
	public void TestFirefox() {
			
				WebDriver firefoxDriver = new FirefoxDriver();

				firefoxDriver.get("http://localhost/litecart/en/");
		        WebElement element = firefoxDriver.findElement(By.name("query"));
		        element.sendKeys("Yellow Duck");
		        element.submit();
	            firefoxDriver.quit();

		}
		    
	}
